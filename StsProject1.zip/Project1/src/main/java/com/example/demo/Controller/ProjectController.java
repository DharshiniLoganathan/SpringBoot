package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.project;
import com.example.demo.Repo.ProjectRepo;

@RestController
public class ProjectController {
@Autowired
ProjectRepo repo;

@GetMapping("/get")
public List<project>getmethod(){
	return repo.find();
}
@GetMapping("/get/{id}")
public project getid(@PathVariable int id) {
	return repo.getid(id);
}
@PostMapping("/post")
public void postmethod(@RequestBody project p) {
	repo.save(p);
}
@PutMapping("/put/{id}/{name}")
public void updatemethod(@PathVariable int id,@PathVariable String name) {
	repo.putmet(id,name);
}
@PutMapping("/put/{id}")
public void updatem(@PathVariable int id,@RequestBody project p) {
	repo.updatem(id, p.getName(),p.getCls());
}

@DeleteMapping("/delete/{id}")
public void deletemethod(@PathVariable int id) {
repo.deletemethod(id);
}

@GetMapping("/get/check/{id}/{name}")
public String checkid(@PathVariable int id,@PathVariable String name) {
	project p=repo.getid(id);
	if(p!=null) {
		if(p.getId()==id&& p.getName().equals(name)) {
			return "valid";
			
		}
		else {
			return "not match";
		}
		
		}
	else {
		return "invalid";
	}
}

@GetMapping("/get/asc")
public List<project> sorts(){
	return repo.sorts();
	
}
@GetMapping("get/page")
public ResponseEntity<Page<project>>getpage(@RequestParam(defaultValue = "1")int page,@RequestParam(defaultValue = "20")int size){
	PageRequest pageable=PageRequest.of(page,size);
	Page<project>p=repo.findAll(pageable);
	return ResponseEntity.ok(p);
}
}