package com.example.demo.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Entity.project;

import jakarta.transaction.Transactional;



public interface ProjectRepo extends JpaRepository<project, Integer> {
@Query("select s from project s")
	List<project> find();

@Modifying
@Transactional
@Query("insert into project(id,name) values(:id,:name)")
void postmathod(@Param("id")int id,@Param("name") String name);

@Modifying
@Transactional
@Query("update project s set s.name=:name where s.id=:id")
void putmet(int id, String name);


@Modifying
@Transactional
@Query("update project p set p.name=:name,p.cls=:cls where p.id=:id")
void updatem(int id, String name, String cls);


@Modifying
@Transactional
@Query("delete from project p where p.id=:id")
void deletemethod(int id);


@Query("select p from  project p where p.id=:id")
project getid(int id);

@Query("select p from project p order by name")
List<project> sorts();
}